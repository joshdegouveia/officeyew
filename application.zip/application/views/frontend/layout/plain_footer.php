
        <!-- Core JS - includes jquery, bootstrap, popper, in-view and sticky-kit -->
        <script src="<?php echo base_url(); ?>assets/frontend/js/purpose.core.js"></script>
        <!-- Page JS -->
        <script src="<?php echo base_url(); ?>assets/frontend/libs/swiper/dist/js/swiper.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/frontend/libs/select2/dist/js/select2.min.js"></script>
        <!-- Purpose JS -->
        <script src="<?php echo base_url(); ?>assets/frontend/js/purpose.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <!-- Demo JS - remove it when starting your project -->
        <!-- <script src="<?php //echo base_url(); ?>assets/frontend/js/demo.js"></script> -->
        <script src="<?php echo base_url(); ?>assets/frontend/js/custom-js.js"></script>
        <script src="<?php echo base_url(); ?>assets/frontend/js/search.js"></script>
        <script type="text/javascript">
        </script>
    </body>
</html>