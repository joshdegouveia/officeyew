<div class="main-content common-page">
    
    <section class="slice" id="sct-article">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-12">
                <!--<div class="col-lg-12 card">-->
                    <!--<div id="sct-topic">-->
                        <?php echo html_entity_decode(formatOutput($content->body)) ; ?>
                    <!--</div>-->
                </div>
            </div>
        </div>
    </section>
    <?php /* ?>
      <!-- Call to action (v5) -->
      <section class="slice slice-lg bg-dark" id=sct-call-to-action>
      <a href="#sct-call-to-action" class="tongue tongue-up tongue-section-primary" data-scroll-to>
      <i class="fas fa-angle-up"></i>
      </a>
      <div class="container">
      <div class="row justify-content-center align-items-center">
      <div class="col-lg-8 text-center">
      <h3 class="font-weight-400 text-white">I am ready to start a new project with <span class="font-weight-700">Purpose</span> UI Kit.</h3>
      <div class="mt-5">
      <a href="https://themes.getbootstrap.com/product/purpose-website-ui-kit/" class="btn btn-primary rounded-pill hover-translate-y-n3">
      Purchase now<span class="badge badge-pill badge-soft-warning badge-floating border-dark">$ 59</span>
      </a>
      <a href="../../docs/index.html" class="btn btn-link text-white" data-toggle="tooltip" data-placement="bottom" title="Official documentation">Purpose Docs</a>
      </div>
      </div>
      </div>
      </div>
      </section><?php */ ?>
</div>