<?php

defined('BASEPATH') OR exit('No direct script access allowed');



/*

  | -------------------------------------------------------------------------

  | URI ROUTING

  | -------------------------------------------------------------------------

  | This file lets you re-map URI requests to specific controller functions.

  |

  | Typically there is a one-to-one relationship between a URL string

  | and its corresponding controller class/method. The segments in a

  | URL normally follow this pattern:

  |

  |	example.com/class/method/id/

  |

  | In some instances, however, you may want to remap this relationship

  | so that a different class/function is called than the one

  | corresponding to the URL.

  |

  | Please see the user guide for complete details:

  |

  |	https://codeigniter.com/user_guide/general/routing.html

  |

  | -------------------------------------------------------------------------

  | RESERVED ROUTES

  | -------------------------------------------------------------------------

  |

  | There are three reserved routes:

  |

  |	$route['default_controller'] = 'welcome';

  |

  | This route indicates which controller class should be loaded if the

  | URI contains no data. In the above example, the "welcome" class

  | would be loaded.

  |

  |	$route['404_override'] = 'errors/page_missing';

  |

  | This route will tell the Router which controller/method to use if those

  | provided in the URL cannot be matched to a valid route.

  |

  |	$route['translate_uri_dashes'] = FALSE;

  |

  | This is not exactly a route, but allows you to automatically route

  | controller and method names that contain dashes. '-' isn't a valid

  | class or method name character, so it requires translation.

  | When you set this option to TRUE, it will replace ALL dashes in the

  | controller and method URI segments.

  |

  | Examples:	my-controller/index	-> my_controller/index

  |		my-controller/my-method	-> my_controller/my_method

 */

//$route['default_controller'] = 'login';
$route['default_controller'] = 'home';


$route['404_override'] = '';

$route['translate_uri_dashes'] = FALSE;


$route['my-stripe'] = "StripeController";
$route['stripePost']['post'] = "StripeController/stripePost";
$route['stripepostt'] = "StripeController/stripePost";

/* * ****************** Admin Route ****************** */

$route['admin'] = 'admin/auth';
//$route['admin/seller'] = 'admin/users/sellers';
//$route['admin/buyer'] = 'admin/users/buyers';
$route['admin/edit_product/(:any)'] = 'admin/products/editProduct';

/* * ****************** Admin Route ****************** */
/* * ****************** Website Route ****************** */
$route['register'] = "login/register";
$route['sign-in'] = "login/signin";
$route['forgot-password'] = 'login/forgot_password';

$route['login'] = 'login/index';

$route['dashboard'] = 'user/dashboard';

$route['subscription'] = 'login/subscription';

$route['payment'] = 'login/payment';

$route['payment-method'] = 'login/paymentMethod';

$route['thankyou'] = 'login/regSuccess';

$route['newuser/activation/(:any)'] = 'login/activation';

$route['hashtag/(:any)'] = 'search/hashtag';

$route['about-us'] = 'cms_pages/cms/about-us';
$route['who-we-are'] = 'cms_pages/cms/who-we-are';
$route['how-we-work'] = 'cms_pages/cms/how-we-work';
$route['work-with-us'] = 'cms_pages/cms/work-with-us';
$route['terms-condition'] = 'cms_pages/cms/terms-condition';
$route['privacy-policy'] = 'cms_pages/cms/privacy-policy';
$route['trust-safety'] = 'cms_pages/cms/trust-safety';
$route['support'] = 'cms_pages/cms/support';
$route['help'] = 'cms_pages/cms/help';
$route['contact-us'] = 'cms_pages/contact_us';

//================================================
$route['subscription-charges'] = 'home/subscription_and_charges';


$route['subscription-boost/(:any)'] = 'payment/subscription_and_boost';
$route['job-posting-subscription/(:any)'] = 'payment/job_posting_subscription';


$route['installer'] = 'user/installer_listing';
$route['designer'] = 'user/designer_listing';
$route['profile-details/(:any)/(:any)'] = 'user/profile_details';
$route['installer-request'] = 'user/installer_request';


$route['products/categories'] = 'products/product_categories';
$route['products/list/(:any)/(:any)'] = 'products/product_list';
$route['products/list-all'] = 'products/product_list'; // All product list
$route['products/search'] = 'products/product_search';
$route['products/detail/(:any)/(:any)/(:any)/(:any)'] = 'products/product_details'; //=== product details from caregory list [with bread camp] =====//
$route['products/details/(:any)/(:any)'] = 'products/product_details';  //=== product details without bread camp =====//
$route['products/product-purchase/(:any)/(:any)'] = 'products/product_purchase';
$route['products/upload'] = 'products/product_upload';
$route['products/update/(:any)'] = 'products/product_upload';


$route['job-search'] = "user/job_search";
$route['job-details/(:any)/(:any)'] = "user/job_details";





$route['job-candidate'] = "user/job_candidate";
$route['candidate-details/(:any)/(:any)'] = "user/candidate_details";
/* * ****************** Website Route ****************** */
/* * ****************** App Route ****************** */


$route['appregister'] = "App/auth/register";
$route['applogin'] = "App/auth/login";
$route['usertype'] = "App/auth/getuserType";
$route['getcategory'] = "App/auth/getcategory";
$route['allproducts'] = "App/products/getallproducts";
$route['allProduct/(:any)'] = "App/products/getallproducts";
$route['productdetails/(:any)/(:any)'] = "App/products/product_details";



/* * ****************** App Route ****************** */




