<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Auth
 * @property Ion_auth|Ion_auth_model $ion_auth        The ION Auth spark
 * @property CI_Form_validation      $form_validation The form validation library
 */
require_once APPPATH . 'libraries/stripe/vendor/autoload.php';

use \Stripe\Stripe;
use \Stripe\Customer;
use \Stripe\ApiOperations\Create;
use \Stripe\Charge;
use \Stripe\Transfer;
use \Stripe\Token;

class Payment extends BaseController {

    private $apiKey;
    private $stripeService;

    public function __construct() {
        parent::__construct();
        $stripe = getAdminStripe();
//        print_r($stripe);die;
        $this->apiKey = '';
        if (!empty($stripe)) {
            $this->apiKey = $stripe->secret_key;
        }
        // $this->apiKey = 'sk_test_nvGHMb4PVb740YK9CRLRngcR';
        $this->stripeService = new \Stripe\Stripe();
        $this->stripeService->setVerifySslCerts(false);
        $this->stripeService->setApiKey($this->apiKey);
        $this->load->model('Product_model');
        $this->load->model('Users_model');
    }

    public function addCustomer($customerDetailsAry) {
        $customer = new Customer();
        $customerDetails = $customer->create($customerDetailsAry);
        return $customerDetails;
    }

    public function chargeAmountFromCard() {
        $user = authentication(false);
        $post = $this->input->post();

        if (!$post['token']) {
            $this->session->set_flashdata('msg_error', 'Unable to process.');
            redirect(base_url('subscription-charges'), 'refresh');
            exit();
        } else {
            $charge = new Charge();
            $trns = new Transfer();

            if (!empty($user)) {
                $uid = $user['id'];
            } else {
                $uid = 0;
                $this->session->set_flashdata('msg_error', 'Please login.');
                redirect(base_url('subscription-charges'), 'refresh');
                exit();
            }

            $batchid = md5(time());
            if (!isset($_SESSION['subscription_and_boost']) || empty($_SESSION['subscription_and_boost'])) {
                $this->session->set_flashdata('msg_error', 'Please login.');
                redirect(base_url('subscription-charges'), 'refresh');
                exit();
            }
            $subscription_and_boost = $_SESSION['subscription_and_boost'];
            $quentity = 1;
            $subscriptionId = $subscription_and_boost['subscriptionId'];
            $description = $subscription_and_boost['pName'];
            $totalprice = $subscription_and_boost['price'];
            $no_of_product = $subscription_and_boost['no_of_product'];
            $duration_in_days = $subscription_and_boost['duration_in_days'];

            $customerDetailsAry = array(
                'email' => $user['email'], // $post['email'],
                'source' => $post['token']
            );

            $customerResult = $this->addCustomer($customerDetailsAry);

            $postAry = array(
                'customer' => $customerResult->id,
                'amount' => $totalprice * 100, //$post['amount']*100 ,
                'currency' => CURRENCY_CODE, //$post['currency_code'],
                'description' => $description, // $post['item_name'],
                'metadata' => array(
                    'order_id' => $batchid// $post['item_number']
                )
            );
            unset($_SESSION['subscription_and_boost']);

            $result = $charge->create($postAry);

//            echo '<pre>';
//            print_r($result);
//            die;
            //echo '<pre>';print_r($result2);
            if ($result->status == 'succeeded') { //&& $result2->status == 'succeeded'
                $this->Users_model->updateData('subscription_for_boost', ['user_id' => $uid], ['status' => 'Ar']);

                $fields = array(
                    'user_id' => $uid,
                    'order_id' => $batchid,
                    'txn_no' => $result->id,
                    'subscription_id' => $subscriptionId,
                    'price' => $totalprice,
                    'duration_in_days' => $duration_in_days,
                    'product_no' => $no_of_product,
                    'ip' => get_client_ip(),
                    'status' => 'A',
                    'created_at' => date('Y-m-d H:i:s'),
                );
                $insert_id = $this->Product_model->insertData('subscription_for_boost', $fields);
                if ($insert_id) {
                    $this->session->set_flashdata('msg_success', 'Subscription successfully. Please check your dashboard');
                    redirect(base_url('subscription-charges'), 'refresh');
                    exit();
                } else {
                    $this->session->set_flashdata('msg_error', 'Something was wrong');
                    redirect(base_url('subscription-charges'), 'refresh');
                    exit();
                }
            } else {
//                echo '<pre>';
//                print_r($result);
//                die;
                $this->session->set_flashdata('msg_error', 'Something was wrong for payment');
                redirect(base_url('subscription-charges'), 'refresh');
                exit();
            }
        }
    }

    public function subscription_and_boost() {
        unset($_SESSION['subscription_and_boost']);
//        $_SESSION['subscription_and_boost'] = [];
        $ls_subscriptionId = $this->uri->segment(2);
        $subscriptionId = explode('-', $ls_subscriptionId)[0];
        $la_boostData = $this->Users_model->getData('boost_product_charges', ['boost_id' => $subscriptionId]);

        if (!isset($_SESSION['user_data']['id'])) {
            $_SESSION['user_data_url']['login_return_url'] = base_url("subscription-boost/$subscriptionId-" . time());
            redirect(base_url('sign-in'));
        } elseif (empty($la_boostData)) {
            redirect(base_url(), 'refresh');
        } else {
            $user = authentication();
            $row = $la_boostData[0];
            $boost_cat_id = $row->boost_cat_id;
            $no_of_product = ($row->product_posting_type == 'unlimited') ? "Unlimited" : $row->no_of_product;
            $price = 0;
            $pName = '';
            if ($boost_cat_id == 1) {
                $price = $row->month_wise_price;
                $pName = ($row->product_posting_type == 'unlimited') ? ucfirst($row->product_posting_type) : $row->no_of_product;
                $pName .= " products posting per month";
                $duration_in_days = 30;
            } elseif ($boost_cat_id == 2) {
                $price = $row->week_wise_price;
                $pName = ($row->product_posting_type == 'unlimited') ? ucfirst($row->product_posting_type) : $row->no_of_product;
                $pName .= " products posting for $row->no_of_weeks weeks";
                $duration_in_days = 7 * $row->no_of_weeks;
            }

            $_SESSION['subscription_and_boost']['subscriptionId'] = $subscriptionId;
            $_SESSION['subscription_and_boost']['pName'] = $pName;
            $_SESSION['subscription_and_boost']['price'] = $price;
            $_SESSION['subscription_and_boost']['no_of_product'] = $no_of_product;
            $_SESSION['subscription_and_boost']['duration_in_days'] = $duration_in_days;

            $stripe = getAdminStripe();

            $uid = $user['id'];
            $this->commonData['header_flag'] = 'text_only';
            $this->commonData['title'] = "Payment for boost product";
            $this->commonData['subscriptionId'] = $subscriptionId;
            $this->commonData['pName'] = $pName;
            $this->commonData['price'] = $price;
            $this->commonData['secret_key'] = $stripe->secret_key;
            $this->commonData['publish_key'] = $stripe->publish_key;
            $this->loadFScreen('frontend/payment/payment');
        }

//        print_r($user);
//        die($subscriptionId);
    }

    public function job_posting_subscription() {
        unset($_SESSION['job_posting_subscription']);
//        $_SESSION['job_posting_subscription'] = [];
        $ls_subscriptionId = $this->uri->segment(2);
        $subscriptionId = explode('-', $ls_subscriptionId)[0];
        $la_boostData = $this->Users_model->getData('job_posting_charges', ['job_posting_charges_id' => $subscriptionId]);

        if (!isset($_SESSION['user_data']['id'])) {
            $_SESSION['user_data_url']['login_return_url'] = base_url("job-posting-subscription/$subscriptionId-" . time());
            redirect(base_url('sign-in'));
        } elseif (empty($la_boostData)) {
            redirect(base_url(), 'refresh');
        } else {
            $user = authentication();
            $row = $la_boostData[0];
//            print_r($row);
//            die;
            $price = 0;
            $pName = '';
            if ($row->job_category == 'per_post') {
                $price = $row->price;
                $pName = $row->description;
                $duration_in_days = 7 * $row->duration_in_week;
                $no_of_product = 0;
            } elseif ($row->job_category == 'monthly') {
                $price = $row->price;
                $pName = CURRENCY . $row->price . " for endless searches";
                $duration_in_days = 30;
                $no_of_product = 0;
            } elseif ($row->job_category == 'one_time') {
                $price = $row->price;
                $pName = CURRENCY . $row->price . " for " . $row->resume_number . " resumes";
                $duration_in_days = 0;
                $no_of_product = $row->resume_number;
            }
 

            $_SESSION['job_posting_subscription']['subscriptionId'] = $subscriptionId;
            $_SESSION['job_posting_subscription']['pName'] = $pName;
            $_SESSION['job_posting_subscription']['price'] = $price;
            $_SESSION['job_posting_subscription']['no_of_product'] = $no_of_product;
            $_SESSION['job_posting_subscription']['duration_in_days'] = $duration_in_days;

            $stripe = getAdminStripe();

            $uid = $user['id'];
            $this->commonData['header_flag'] = 'text_only';
            $this->commonData['title'] = "Payment for job posting";
            $this->commonData['subscriptionId'] = $subscriptionId;
            $this->commonData['pName'] = $pName;
            $this->commonData['price'] = $price;
            $this->commonData['secret_key'] = $stripe->secret_key;
            $this->commonData['publish_key'] = $stripe->publish_key;
            $this->loadFScreen('frontend/payment/job_posting_payment');
        }

//        print_r($user);
//        die($subscriptionId);
    }

    
    
    public function jobPostChargeAmountFromCard() {
        $user = authentication(false);
        $post = $this->input->post();

        if (!$post['token']) {
            $this->session->set_flashdata('msg_error', 'Unable to process.');
            redirect(base_url('subscription-charges'), 'refresh');
            exit();
        } else {
            $charge = new Charge();
            $trns = new Transfer();

            if (!empty($user)) {
                $uid = $user['id'];
            } else {
                $uid = 0;
                $this->session->set_flashdata('msg_error', 'Please login.');
                redirect(base_url('subscription-charges'), 'refresh');
                exit();
            }

            $batchid = md5(time());
            if (!isset($_SESSION['job_posting_subscription']) || empty($_SESSION['job_posting_subscription'])) {
                $this->session->set_flashdata('msg_error', 'Please login.');
                redirect(base_url('subscription-charges'), 'refresh');
                exit();
            }
            $job_posting_subscription = $_SESSION['job_posting_subscription'];
            $quentity = 1;
            $subscriptionId = $job_posting_subscription['subscriptionId'];
            $description = $job_posting_subscription['pName'];
            $totalprice = $job_posting_subscription['price'];
            $no_of_product = $job_posting_subscription['no_of_product'];
            $duration_in_days = $job_posting_subscription['duration_in_days'];

            $customerDetailsAry = array(
                'email' => $user['email'], // $post['email'],
                'source' => $post['token']
            );

            $customerResult = $this->addCustomer($customerDetailsAry);

            $postAry = array(
                'customer' => $customerResult->id,
                'amount' => $totalprice * 100, //$post['amount']*100 ,
                'currency' => CURRENCY_CODE, //$post['currency_code'],
                'description' => $description, // $post['item_name'],
                'metadata' => array(
                    'order_id' => $batchid// $post['item_number']
                )
            );
            unset($_SESSION['job_posting_subscription']);

            $result = $charge->create($postAry);

//            echo '<pre>';
//            print_r($result);
//            die;
            //echo '<pre>';print_r($result2);
            if ($result->status == 'succeeded') { //&& $result2->status == 'succeeded'
                $this->Users_model->updateData('job_posting_subscription', ['user_id' => $uid], ['status' => 'Ar']);

                $fields = array(
                    'user_id' => $uid,
                    'order_id' => $batchid,
                    'txn_no' => $result->id,
                    'subscription_id' => $subscriptionId,
                    'price' => $totalprice,
                    'duration_in_days' => $duration_in_days,
                    'product_no' => $no_of_product,
                    'ip' => get_client_ip(),
                    'status' => 'A',
                    'created_at' => date('Y-m-d H:i:s'),
                );
                $insert_id = $this->Product_model->insertData('job_posting_subscription', $fields);
                if ($insert_id) {
                    $this->session->set_flashdata('msg_success', 'Subscription successfully.');
//                    $this->session->set_flashdata('msg_success', 'Subscription successfully. Please check your dashboard');
                    redirect(base_url('subscription-charges'), 'refresh');
                    exit();
                } else {
                    $this->session->set_flashdata('msg_error', 'Something was wrong');
                    redirect(base_url('subscription-charges'), 'refresh');
                    exit();
                }
            } else {
//                echo '<pre>';
//                print_r($result);
//                die;
                $this->session->set_flashdata('msg_error', 'Something was wrong for payment');
                redirect(base_url('subscription-charges'), 'refresh');
                exit();
            }
        }
    }

}
