    <?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class Products extends BaseController {
		public function __construct() {
			parent::__construct();
			// $this->load->library('facebook');
            $this->load->model('Users_model');
            $this->load->model('Product_model');
           
		}

            public function getallproducts(){
                $catid = $this->uri->segment(2);
                $orderBy['orderBy'] = 'p.is_boost';
                $orderBy['type'] = 'DESC';
                $currentPage = 1;
                if (isset($_GET['pg']) && ($_GET['pg'] > 0)) {
                    $currentPage = $_GET['pg'];
                }
                $limit['limit'] = ITEM_PRODACT_LG;
                $limit['offset'] = (($currentPage - 1 ) * ITEM_PRODACT_LG);
                $la_all_products = $this->Product_model->getProductList($catid, 0, $limit, '', '', '', $orderBy);
                echo json_encode($la_all_products);
        
            }

            public function product_details() {
              
                $productId = $this->uri->segment(2);
                $userId = $this->uri->segment(3);
                $product = $this->Product_model->single_product($productId);
                $product_location = $this->Product_model->single_product_location($productId);
                $my_favorites = $this->Product_model->my_favorites($productId, $userId);
                if (!empty($my_favorites)) {
                    $my_favorites = $my_favorites[0];
                }
                $la_proMoreImg = $this->Users_model->getData('product_images', array('product_id' => $productId));
                $la_sellerReview = $this->Product_model->get_seller_review($productId);
        
        //        print_r($product_location);die;
        
              

                $response['prodData'] = $product[0];
                $response['product_location'] = $product_location;
                $response['my_favorites'] = $my_favorites;
                $response['la_proMoreImg'] = $la_proMoreImg;
                $response['la_sellerReview'] = $la_sellerReview;
                $response['success'] = true;

                echo json_encode($response);
            }


        }
    ?>