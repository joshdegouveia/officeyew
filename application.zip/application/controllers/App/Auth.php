<?php
	defined('BASEPATH') OR exit('No direct script access allowed');
	class Auth extends BaseController {
		public function __construct() {
			parent::__construct();
			// $this->load->library('facebook');
			$this->load->model('Login_model');
            $this->load->model('users_model');
            $this->load->model('Product_model');
		}
		public function getuserType() {
			$la_groups = $this->users_model->getData('groups', ['id !=' => 1]);
			echo json_encode($la_groups);
        }
        
        public function getcategory(){
            $la_categoey = $this->users_model->getData('product_category', ['status' => 1], '*', [], [], ['order_by' => 'name', 'sort' => 'ASC']);
            $response['data'] = $la_categoey;
            $response['success'] = true;
            echo json_encode($response);
            
        }

		public function register() {
      
		
        if ($this->input->post()) {
            $data = json_decode(file_get_contents('php://input'), true);
            $la_userType = $data['user_type'];
            //echo json_encode($data);
            $post_data = array();
            $activation_code = mt_rand(1000,9999);
            $post_data['uniqueid'] = uniqid();
            $post_data['first_name'] = trim($data['first_name']);
            $post_data['last_name'] = trim($data['last_name']);
            $post_data['email'] = trim($data['email']);
            $post_data['password'] = trim($data['password']);

            $post_data['activation_code'] = $activation_code;
            $post_data['active'] = 0;
            $post_data['created_date'] = time();
            $post_data['modified_date'] = time();
            $post_data['ip_address'] = $_SERVER['REMOTE_ADDR'];
            $uid = $this->Login_model->insert('users', $post_data);
                if ($uid > 0) {
                foreach ($la_userType as $li_userTypeId) {
                    $this->Login_model->insert('users_groups', ['user_id' => $uid, 'group_id' => $li_userTypeId]);
                }
            }
                // mail for confurmation
            $name = $data['first_name'] . ' ' . $data['last_name'];
            $name = ucwords($name);
            $config = array(
                'mailtype' => 'html',
                'charset' => 'utf-8',
                'priority' => '1'
            );
            $this->email->initialize($config);
            $this->email->from(SITE_EMAIL, SITE_NAME);
            // $this->email->to('rupam.brainium@gmail.com');
            $this->email->to($data['email']);
            $data_arr = array(
                'username' => $name,
                'email' => $data['email'],
                'active_link' => base_url() . 'login/activation/' . $activation_code,
            );
            $this->email->subject(SITE_NAME . ' Register Activation Link');
            $body = $this->load->view('frontend/email/registration.php', $data_arr, TRUE);
            $this->email->message($body);
            @$this->email->send();
                    // // mail*/

            $response['data'] = $uid;
            $response['success'] = true;
            $response['msg'] = "You have Successfully Regsiter";

     
        }else{
            $response = array('success' => false, 'msg' => 'something went wrong!');
        }
        echo json_encode($response);


        /*$this->commonData['header_flag'] = 'text_only';
        $this->commonData['title'] = 'Registration';
        $this->commonData['user'] = $user;
        $this->commonData['la_groups'] = $la_groups;

        $this->loadFScreen('frontend/user/register');*/
    }
    public function login() {
        if ($this->input->post()) {
            $data = json_decode(file_get_contents('php://input'), true);
            $post_data = array();
            $post_data['email'] = trim($data['email']);
            $post_data['password'] = md5($data['password']);
           
            $user = $this->users_model->getData('users', $post_data);
            if (!empty($user)) {
                $user = $user[0];
                $user_type = $this->users_model->getUserType(['email' => $post_data['email']]);
                $user->type = explode(',', $user_type->user_types)[0];
                $user->user_types = explode(',', $user_type->user_types);

//                    print_r($user);die;

                /*if ($user->active == 0 && !empty($user)) {
                    $response = array('success' => false, 'msg' => 'Please active your account and try again.');
                } else if ($user->active == 1 && !empty($user)) {
                    $fields = array(
                        'last_activity' => time()
                    );
                    $this->users_model->updateData('users', array('id' => $user->id), $fields);
                    
                    if (isset($_GET['type']) && ($_GET['type'] == 'seller')) { // dirrect login to seller =========
                        if (in_array('seller', $user->user_types)) {
                            $user->type = 'seller';
                        }else{
                            //$this->session->set_flashdata('msg_error', 'You do not have permission to sell.');
                            $response = array('success' => false, 'msg' => 'You do not have permission to sell.');
                        }
                    }
                    
                    //$this->setUserData($user);*/
                    
                $response['data'] = $user;
                $response['success'] = true;
                $response['msg'] = "You have Successfully Login";
                 
            }else{
                $response = array('success' => false, 'msg' => 'Please Check Your Username And Password!');
            }
        }else{
            $response = array('success' => false, 'msg' => 'something went wrong!');
        }
        echo json_encode($response);
    }
    public function getallproducts(){
          
        $orderBy['orderBy'] = 'p.is_boost';
        $orderBy['type'] = 'DESC';
        $la_all_products = $this->Product_model->getProductList('', 0, $limit, '', '', '', $orderBy);
        $response['data'] = $la_categoey;
        $response['success'] = true;
        echo json_encode($response);

    }


 


	}
?>